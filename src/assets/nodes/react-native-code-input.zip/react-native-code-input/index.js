import ConfirmationCodeInput from './components/ConfirmationCodeInput';
export default ConfirmationCodeInput;