import * as React from 'react';
export default class Contacts extends React.Component {
    private renderItem;
    private ItemSeparator;
    render(): JSX.Element;
}
