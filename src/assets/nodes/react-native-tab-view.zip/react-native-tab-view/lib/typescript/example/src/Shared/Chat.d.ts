import * as React from 'react';
export default class Chat extends React.Component {
    render(): JSX.Element;
}
