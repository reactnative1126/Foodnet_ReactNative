import * as React from 'react';
export default class Article extends React.Component {
    render(): JSX.Element;
}
