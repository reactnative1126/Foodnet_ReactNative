declare function CoverflowExample(): JSX.Element;
declare namespace CoverflowExample {
    var title: string;
    var backgroundColor: string;
    var appbarElevation: number;
}
export default CoverflowExample;
