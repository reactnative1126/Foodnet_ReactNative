import * as React from 'react';
export default class Albums extends React.Component {
    render(): JSX.Element;
}
