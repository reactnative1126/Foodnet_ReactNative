import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    top: 2,
    justifyContent: 'center',
  },
});
